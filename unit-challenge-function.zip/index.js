// dependencies
const AWS = require('aws-sdk')
const readline = require('readline')
const util = require('util')

// get reference to S3 client
const s3 = new AWS.S3()

const FILE_TEXT_TYPE = "txt"

/**
 * 
 * @param {Object} event - API Gateway Lambda Proxy Input Format
 *
 * @returns {Object} object - API Gateway Lambda Proxy Output Format
 * 
 */
exports.handler = async (event) => {
    const responseCode = 200
    const srcBucket = event.Records[0].s3.bucket.name
    // Object key may have spaces or unicode non-ASCII characters.
    const srcKey = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, " "))

    // Infer the file type from the suffix.
    const typeMatch = srcKey.match(/\.([^.]*)$/)
    if (!typeMatch) {
        let message = "Could not determine the file type"
        errorHandler(event, message)
    }

    const fileType = typeMatch[1].toLowerCase();
    if (fileType != FILE_TEXT_TYPE) {
        let message = `Unsupported file type: ${fileType}`
        return errorHandler(event, message)
    }

    const params = {
        Bucket: srcBucket,
        Key: srcKey
    }
    
    try {
        await s3.headObject(params).promise()
        try {
            var fileStream = s3.getObject(params).createReadStream()
            console.debug("File Processing - START")
            await logFileStreamLineByLine(fileStream)
            await s3.deleteObject(params).promise();
            console.debug(`File Processing - END: ${srcKey} deteled from bucket ${srcBucket}`)
        } catch (err) {
            return errorHandler(event, err)
        }
    } catch (err) {
        let message = `File not Found ERROR: ${err.code}`
        return errorHandler(event, message)
    }

    let responseBody = {
        message: 'File processed with success',
        input: event
    }
    
    let response = {
        statusCode: responseCode,
        body: JSON.stringify(responseBody)
    }
    
    return response
}

async function logFileStreamLineByLine(fileStream) {
    const rl = readline.createInterface({
      input: fileStream,
      terminal: false,
      crlfDelay: Infinity
    });
    
    for await (const line of rl) {
        console.log(line);
    }
}

function errorHandler(event, message) {
    let errorMessage = "Error processing event:\nError Message: " + message + "\n Event details:\n" + util.inspect(event, {depth: 5})
    console.error(errorMessage)
    throw new Error(message)
}
